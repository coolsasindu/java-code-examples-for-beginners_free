package r;

public class R {
  public void r1() {
    System.out.println("r1");
  }
}