package q;
import r.*;
import s.*;

class ImportDemo {

  public static void main(String args[]) {
    R r = new R();
    r.r1();
    S s = new S();
    s.s1();
  }
}