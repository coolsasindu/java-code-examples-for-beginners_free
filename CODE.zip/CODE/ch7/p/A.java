package p;

class A {
  void a1() {
    System.out.println("a1");
  }
}