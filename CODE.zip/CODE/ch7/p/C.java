package p;

class C {
  void c1() {
    System.out.println("c1");
  }
}