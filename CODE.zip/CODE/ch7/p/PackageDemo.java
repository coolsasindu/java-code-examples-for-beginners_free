package p;

class PackageDemo {

  public static void main(String args[]) {
    A a = new A();
    a.a1();
    B b = new B();
    b.b1();
    C c = new C();
    c.c1();
  }
}