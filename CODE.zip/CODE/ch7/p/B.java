package p;

class B {
  void b1() {
    System.out.println("b1");
  }
}