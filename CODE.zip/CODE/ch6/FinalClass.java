final class V1 {
}

class V2 extends V1 {
}

class FinalClass {
  public static void main(String args[]) {
    V1 obj = new V1();
  }
}
