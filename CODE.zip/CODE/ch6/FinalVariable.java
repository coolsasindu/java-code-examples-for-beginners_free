class L {
  static final int x = 5;
}

class FinalVariable {
  public static void main(String args[]) {
    System.out.println(L.x);
  }
}