class V {
  static final int v = 5;
}

class StaticFinal {

  public static void main(String args[]) {
    System.out.println(V.v);
  }
}