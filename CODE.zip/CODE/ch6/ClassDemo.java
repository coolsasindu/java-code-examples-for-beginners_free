class ClassDemo {

  public static void main(String args[]) {

    Integer obj = new Integer(8);
    Class cls = obj.getClass();
    System.out.println(cls);
  }
}
