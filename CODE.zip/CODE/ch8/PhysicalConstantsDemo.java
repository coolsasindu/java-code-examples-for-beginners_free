class PhysicalConstantsDemo {
  public static void main(String args[]) {
    System.out.println(PhysicalConstants.G);
    System.out.println(PhysicalConstants.C);
    System.out.println(PhysicalConstants.A);
  }
}