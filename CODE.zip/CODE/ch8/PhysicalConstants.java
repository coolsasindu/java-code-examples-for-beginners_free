public interface PhysicalConstants {
  double G = 9.8;
  double C = 3E8;
  double A = 6.02E23;
}