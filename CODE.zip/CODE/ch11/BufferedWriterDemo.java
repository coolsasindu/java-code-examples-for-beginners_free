import java.io.*;

class BufferedWriterDemo {

  public static void main(String args[]) {

    try {

      // Create a file writer
      FileWriter fw = new FileWriter(args[0]);

      // Create a buffered writer
      BufferedWriter bw = new BufferedWriter(fw);

      // Write strings to the file
      for(int i = 0; i < 12; i++) {
        bw.write("Line " + i + "\n");
      }

      // Close buffered writer
      bw.close();
    }
    catch(Exception e) {
      System.out.println("Exception: " + e);
    }
  }
}