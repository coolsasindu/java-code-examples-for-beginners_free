class Example1 {
  public static void main(String args[]) {
    System.out.println("This is the output from Example1");
  }
}
