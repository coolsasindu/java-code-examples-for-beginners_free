public class OutputVariables {
  public static void main(String args[]) {
    char ch = 'X';
    short s = 456;
    double d = 123.009;
    System.out.println("ch is " + ch);
    System.out.println("s is " + s);
    System.out.println("d is " + d);
  }
}