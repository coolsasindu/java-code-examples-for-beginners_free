class ArrayInitializer {

  public static void main(String args[]) {

    // Declare, allocate, initialize
    int myarray[] = { 33, 71, -16, 45 };

    // Display length
    System.out.println("myarray.length = " + 
      myarray.length);

    // Display elements
    System.out.println(myarray[0]);
    System.out.println(myarray[1]);
    System.out.println(myarray[2]);
    System.out.println(myarray[3]);
  }
}