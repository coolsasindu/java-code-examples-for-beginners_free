class Concatenation {
  public static void main(String args[]) {
    System.out.println("My book " +
      "will teach you " +
      "about Java programming");
  }
}