class UninitializedVariables {
  public static void main(String args[]) {
    char c;
    boolean flag;
    System.out.println(c);
    System.out.println(flag);
  }
}