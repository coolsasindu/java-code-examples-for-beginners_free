class NarrowingConversion {
  public static void main(String args[]) {
    byte b;
    int i = 258;
    b = (byte)i;
    System.out.println(b);
  }
}
