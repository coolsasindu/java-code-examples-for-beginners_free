class AssignmentProblem {
  public static void main(String args[]) {
    byte b1 = 1;
    byte b2 = 2;
    byte b3 = b1 * b2;
    System.out.println(b3);
  }
}
