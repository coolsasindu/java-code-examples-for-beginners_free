class FourByteArray {
  public static void main(String args[]) {
    byte array[] = new byte[4];
    array[0] = 11;
    array[1] = 26;
    array[2] = 56;
    array[3] = -90;
    System.out.println(array[0]);
    System.out.println(array[1]);
    System.out.println(array[2]);
    System.out.println(array[3]);
  }
}
    