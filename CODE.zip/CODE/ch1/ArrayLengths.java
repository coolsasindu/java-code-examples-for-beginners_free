class ArrayLengths {
  public static void main(String args[]) {
    int iarray[][] = {
      { 44 },
      { -22, 16 },
      { 11, -12, 99 }
    };
    System.out.println("iarray.length = " + iarray.length);
    System.out.println("iarray[0].length = " + iarray[0].length);
    System.out.println("iarray[1].length = " + iarray[1].length);
    System.out.println("iarray[2].length = " + iarray[2].length);
  }
}