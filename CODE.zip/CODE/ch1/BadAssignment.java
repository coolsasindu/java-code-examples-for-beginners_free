class BadAssignment {
  public static void main(String args[]) {
    byte b;
    int i = 127;
    b = i;
    System.out.println(b);
  }
}
