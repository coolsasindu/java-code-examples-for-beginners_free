class WideningConversion {
  public static void main(String args[]) {
    byte b = 127;
    int i;
    i = b;
    System.out.println(i);
  }
}
