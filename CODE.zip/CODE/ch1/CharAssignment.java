class CharAssignment {
  public static void main(String args[]) {
    char ch = 'A';
    int i = ch;
    System.out.println(i);
  }
}
