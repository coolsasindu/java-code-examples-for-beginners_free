class GoodAssignment {
  public static void main(String args[]) {
    byte b;
    int i = 127;
    b = (byte)i;
    System.out.println(b);
  }
}
