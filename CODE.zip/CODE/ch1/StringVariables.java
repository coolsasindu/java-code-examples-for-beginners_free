class StringVariables {
  public static void main(String args[]) {
    String s1 = "My book teaches ";
    String s2 = "you how to ";
    String s3 = "use Java";
    System.out.println(s1 + s2 + s3);
  }
}