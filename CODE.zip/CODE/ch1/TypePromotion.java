class TypePromotion {
  public static void main(String args[]) {
    int i;
    float f;
    i = 10;
    f = 23.25f;
    System.out.println(i * f);
  }
}
