class JulietQuote {
  public static void main(String args[]) {
    String s = "Juliet said: " +
      "\"Romeo, where art thou?\"";
    System.out.println(s);
  }
}