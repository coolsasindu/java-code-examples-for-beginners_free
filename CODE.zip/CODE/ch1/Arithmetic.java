public class Arithmetic {
  public static void main(String args[]) {
    System.out.print(5/2);
    System.out.print(" " + 5%2);
    System.out.print(" " + 4/2);
    System.out.println(" " + 4%2);
  }
}