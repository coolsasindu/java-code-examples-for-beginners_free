class DisplayFloat {
  public static void main(String args[]) {
    float price;
    price = 45.35f;
    System.out.print("The price is ");
    System.out.println(price);
  }
}

