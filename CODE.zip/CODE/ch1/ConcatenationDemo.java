class ConcatenationDemo {
  public static void main(String args[]) {
    String myName = "Joe " + "O'Neil";
    System.out.println(myName);
  }
}