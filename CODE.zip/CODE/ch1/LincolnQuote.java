class LincolnQuote {
  public static void main(String args[]) {
    String s = "Lincoln said: " +
      "\"Four score and seven years ago\"";
    System.out.println(s);
  }
}