class Example2 {
  public static void main(String args[]) {
    System.out.println("This is on the first line.");
    System.out.println("This is on the second line.");
  }
}
