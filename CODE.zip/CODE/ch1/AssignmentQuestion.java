class AssignmentQuestion {
  public static void main(String args[]) {
    short s1 = 1;
    short s2 = s1 + 1;
    System.out.println(s2);
  }
}