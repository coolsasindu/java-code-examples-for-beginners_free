class DrivingTime {
  public static void main(String args[]) {
    float h = 3000/75;
    System.out.println(h + 
      " hours are required to drive " +
      "from New York to Los Angeles ");
  }
}