class OneDimensionArray {

  public static void main(String args[]) {

    // Declare and allocate space
    int myarray[] = new int[4];

    // Initialize elements
    myarray[0] = 33;
    myarray[1] = 71;
    myarray[2] = -16;
    myarray[3] = 45;

    // Display length
    System.out.println("myarray.length = " + 
      myarray.length);

    // Display elements
    System.out.println(myarray[0]);
    System.out.println(myarray[1]);
    System.out.println(myarray[2]);
    System.out.println(myarray[3]);
  }
}