class Truncation {
  public static void main(String args[]) {
    float f = 23.9999f;
    int i = (int)f;
    System.out.println(i);
  }
}
