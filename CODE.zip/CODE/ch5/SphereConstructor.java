class Sphere2 {
  double x;
  double y;
  double z;
  double radius;

  Sphere2(double ax, double ay, double az, double aradius) {
    x = ax;
    y = ay;
    z = az;
    radius = aradius;
  }
}

class SphereConstructor {

  public static void main(String args[]) {

    Sphere2 s = new Sphere2(100, -40, 56.5, 8);
    System.out.println("s.x = " + s.x);
    System.out.println("s.y = " + s.y);
    System.out.println("s.z = " + s.z);
    System.out.println("s.radius = " + s.radius);
  }
}