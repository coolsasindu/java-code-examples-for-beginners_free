class BeforeIncrementDecrement {
  public static void main(String args[]) {
    int a, b;
    a = 1;
    a = a + 1;
    b = a;
    b = b - 1;
    System.out.println(a + " " + b);
  }
}