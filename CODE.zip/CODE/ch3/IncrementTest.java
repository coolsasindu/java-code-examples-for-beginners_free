class IncrementTest {
  public static void main(String args[]) {
    int i, j;
    i = 10;
    j = i++;

    /* this will print 11 10 */
    System.out.println("i and j: " +  i + " " + j);
  }
}
