class NewlineDemo {
  public static void main(String args[]) {
    System.out.print("This is line one\n");
    System.out.print("This is line two\n");
    System.out.print("This is line three");
  }
}
