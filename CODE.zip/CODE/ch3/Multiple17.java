class Multiple17 {
  public static void main(String args[]) {
    for(int i = 17; i < 101; i = i + 1) {
      if((i % 17) == 0) System.out.print(i + " ");
    }
  }
}