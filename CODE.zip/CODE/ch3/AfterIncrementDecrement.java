class AfterIncrementDecrement {
  public static void main(String args[]) {
    int a = 1;
    ++a;
    int b = a;
    --b;
    System.out.println(a + " " + b);
  }
}