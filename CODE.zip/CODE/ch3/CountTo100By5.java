public class CountTo100By5 {
  public static void main(String args[]) {
    for(int i = 0; i < 101; i = i + 5)
      System.out.print(i + " ");
  }
}