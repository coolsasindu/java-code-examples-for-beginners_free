class TernaryOperatorDemo2 {
  public static void main(String args[]) {
    int i = 9;
    System.out.println((i % 2 == 0) ? "Even" : "Odd");
  }
}