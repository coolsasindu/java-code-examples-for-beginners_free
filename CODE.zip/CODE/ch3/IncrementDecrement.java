class IncrementDecrement {
  public static void main(String args[]) {
    int i;
    i = 0;
    System.out.println(++i);  // prints 1
    System.out.println(i++);  // prints 1
    System.out.println(i);    // prints 2
    System.out.println(--i);  // prints 1
    System.out.println(i--);  // prints 1
    System.out.println(i);    // prints 0
  }
}