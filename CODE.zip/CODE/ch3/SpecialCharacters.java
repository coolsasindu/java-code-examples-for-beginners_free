class SpecialCharacters {
  public static void main(String args[]) {
    System.out.print("\u00a0 \u00a1 \u00a2 \u00a3");
  }
}