class IncrementTest2 {
  public static void main(String args[]) {
    int i, j;
    i = 10;
    j = ++i;

    /* this will print 11 11 */
    System.out.println("i and j: " +  i + " " + j);
  }
}
