class IfDemo {
  public static void main(String args[]) {
    if(args.length == 0) 
      System.out.println("You must have command line arguments");
  }
}
    