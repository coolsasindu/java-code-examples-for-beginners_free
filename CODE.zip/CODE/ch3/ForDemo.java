public class ForDemo {
  public static void main(String args[]) {
    for(int num = 1; num < 11; num = num + 1) 
      System.out.print(num + " ");
    System.out.println("terminating");
  }
}