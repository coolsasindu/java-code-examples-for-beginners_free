class Logarithm {
  public static void main(String args[]) {
    double d = Double.valueOf(args[0]).doubleValue();
    System.out.println(Math.log(d));
  }
}