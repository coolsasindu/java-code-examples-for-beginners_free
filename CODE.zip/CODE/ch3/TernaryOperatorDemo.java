class TernaryOperatorDemo {
  public static void main(String args[]) {
    int i = 10;
    int j = 5;
    System.out.println((i > j) ? i : j);
  }
}