class ZeroDivide {
  public static void main(String args[]) {
    double d1 = Double.valueOf(args[0]).doubleValue();
    double d2 = Double.valueOf(args[1]).doubleValue();
    if(d2 == 0) System.out.print("Cannot divide by zero");
    else System.out.print("Answer is: " + d1/d2);
  }
}
    