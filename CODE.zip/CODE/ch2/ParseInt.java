class ParseInt {
  public static void main(String args[]) {
    String s = "125";
    int i = Integer.parseInt(s);
    i =  i + 10;
    System.out.println(i);
  }
}