class Add2Integers {

  public static void main(String args[]) {

    // Get first integer
    int i = Integer.parseInt(args[0]);

    // Get second integer
    int j = Integer.parseInt(args[1]);

    // Display their sum
    int sum = i + j;
    System.out.print("Sum is " + sum);
  }
}