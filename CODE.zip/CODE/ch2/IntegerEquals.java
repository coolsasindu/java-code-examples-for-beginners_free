class IntegerEquals {
  public static void main(String args[]) {
    Integer iobj1 = new Integer(5);
    Integer iobj2 = new Integer("5");
    System.out.println(iobj1.equals(iobj2));
  }
}