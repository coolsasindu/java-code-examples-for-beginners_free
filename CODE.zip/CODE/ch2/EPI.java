class EPI {
  public static void main(String args[]) {
    System.out.println("E = " + Math.E);
    System.out.println("PI = " + Math.PI);
  }
}