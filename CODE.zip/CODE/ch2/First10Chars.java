class First10Chars {
  public static void main(String args[]) {
    String s = "One Two Three Four Five Six Seven";
    String substring = s.substring(0, 10);
    System.out.println(substring);
  }
}