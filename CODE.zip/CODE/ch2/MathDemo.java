class MathDemo {
  public static void main(String args[]) {
    System.out.println("Max of -8 and -4 is " +
      Math.max(-8, -4));
    System.out.println("Min of -8 and -4 is " + 
      Math.min(-8, -4));
    System.out.println("Absolute value of -18 is " +
      Math.abs(-18));
    System.out.println("The ceiling of 45.7 is " +
      Math.ceil(45.7));
    System.out.println("The floor of 45.7 is " +
      Math.floor(45.7));
  }
}
    