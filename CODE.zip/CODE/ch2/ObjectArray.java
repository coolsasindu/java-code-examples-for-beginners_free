class ObjectArray {
  public static void main(String args[]) {
    Object array[] = new Object[5];
    array[0] = new Integer(4);
    array[1] = new String("Hello");
    array[2] = new Boolean("true");
    array[3] = new Character('a');
    array[4] = new Double(45.67);
    System.out.println(array[0]);
    System.out.println(array[1]);
    System.out.println(array[2]);
    System.out.println(array[3]);
    System.out.println(array[4]);
  }
}