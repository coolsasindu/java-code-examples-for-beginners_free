class CharacterDemo {
  public static void main(String args[]) {
    System.out.println(Character.isDigit('8'));
    System.out.println(Character.isLetter('A'));
    System.out.println(Character.isLetterOrDigit('A'));
    System.out.println(Character.isLowerCase('a'));
    System.out.println(Character.toLowerCase('A'));
  }
}
    