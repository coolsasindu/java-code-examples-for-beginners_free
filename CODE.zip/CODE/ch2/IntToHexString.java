class IntToHexString {
  public static void main(String args[]) {
    System.out.println(Integer.toHexString(100));
  }
}