class Triangle {
  public static void main(String args[]) {
    double a = 4.5;
    double b = 8.9;
    double hypotenuse = Math.sqrt(a * a + b * b);
    System.out.println("Sides are " + a + " " + b);
    System.out.println("Hypotenuse is " + hypotenuse);
  }
}