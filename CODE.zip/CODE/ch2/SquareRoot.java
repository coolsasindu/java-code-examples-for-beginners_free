class SquareRoot {
  public static void main(String args[]) {
    System.out.println(Math.sqrt(23.45));
  }
}