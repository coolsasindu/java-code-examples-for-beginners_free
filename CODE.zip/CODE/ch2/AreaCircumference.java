class AreaCircumference {
  public static void main(String args[]) {
    double radius = 5;
    double area = Math.PI * radius * radius;
    double circumference = 2 * Math.PI * radius;
    System.out.println("Radius is " + radius);
    System.out.println("Area is " + area);
    System.out.println("Circumference is " + 
      circumference);
  }
}