class ExpressionLoop {
  public static void main(String args[]) {
    int i = Integer.parseInt(args[0]);
    for( ; i > 0; i--) System.out.print(i + " ");
  }
}