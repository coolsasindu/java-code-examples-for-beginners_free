class VowelCounter {
  public static void main(String args[]) {
    int vowels = 0;
    int i = args[0].length() - 1;
    while(i >= 0) {
      char c = args[0].charAt(i);
      if(c == 'A' || c == 'a')
        ++vowels;
      else if(c == 'e' || c == 'E')
        ++vowels;
      else if(c == 'i' || c == 'I')
        ++vowels;
      else if(c == 'o' || c == 'O')
        ++vowels;
      else if(c == 'u' || c == 'U')
        ++vowels;
      --i;
    }
    System.out.println("The number of vowels is " + vowels);
  }
}
      