class WhileDemo {
  public static void main(String args[]) {
    int i = Integer.parseInt(args[0]);
    while(i > 0) {
      System.out.print(i + " ");
      i--;
    } 
  }
}