class EmptyForIncrement {
  public static void main(String args[]) {
    int i;
    for(i = 0; i < 10; ) {
      System.out.println(i);
      i++;
    }
  }
}