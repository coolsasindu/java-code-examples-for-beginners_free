class SpanishTranslator {
  public static void main(String args[]) {
    if(args[0].equals("One"))
      System.out.println("Uno");
    else if(args[0].equals("Two")) 
      System.out.println("Dos");
    else if(args[0].equals("Three")) 
      System.out.println("Tres");
    else if(args[0].equals("Four")) 
      System.out.println("Quatro");
    else if(args[0].equals("Five")) 
      System.out.println("Cinco");
    else
      System.out.println("Unrecognized input");
  }
}