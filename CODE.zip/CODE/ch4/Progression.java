class Progression {
  public static void main(String args[]) {
    for(int i = 1; i < 1000; i += i) 
      System.out.print(i + " ");
  }
}